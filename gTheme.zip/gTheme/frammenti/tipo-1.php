
<div class="container-fluid px-0 screen-1 sfondo-1">
  <div class="container-fluid px-0 screen-1 velo">
    <div class="container screen-1 pt-5 pb-5">

      <div class="row">

        <div class="col-md-12 col-lg-6 mt-5">
          <h1 class="text-uppercase mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit</h1>
          <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
          incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation
          ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit
          in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat
          non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
          <a href="#" class="btn btn-success">Call to Action</a>
        </div>

        <div class="col-lg-6">
        </div>

      </div>

  </div>
 </div>
</div>
