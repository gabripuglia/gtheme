<?php /* Template Name: Scontent */ ?>

<?php get_header() ?>

  <?php  get_template_part( '/frammenti/tipo-1', 'sezione-eroe' ); ?>

<?php get_footer() ?>
